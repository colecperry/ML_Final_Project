import pandas as pd               # for loading CSVs
import torch                       # PyTorch core
from torch.utils.data import Dataset
from transformers import (
    RobertaTokenizerFast,
    AutoModelForSequenceClassification,
    TrainingArguments,
    Trainer
)

from sklearn.metrics import accuracy_score, precision_recall_fscore_support, classification_report

# ------------------------------
# 1) Load our pre-split CSVs (train + test only)
# ------------------------------
train_df = pd.read_csv("train_split_balanced.csv")
test_df  = pd.read_csv("test_split_balanced.csv")

# ------------------------------
# 2) Prepare labels (map "fake"/"real" to 1/0)
# ------------------------------
label_map    = {"real": 0, "fake": 1}
train_labels = train_df["label"].map(label_map).tolist()
test_labels  = test_df["label"].map(label_map).tolist()

# ------------------------------
# 3) Tokenizer & custom Dataset
# ------------------------------
tokenizer = RobertaTokenizerFast.from_pretrained("roberta-large")

class FakeNewsDataset(Dataset):
    def __init__(self, texts, labels, tokenizer, max_len=256):
        self.texts     = texts
        self.labels    = labels
        self.tokenizer = tokenizer
        self.max_len   = max_len

    def __len__(self):
        return len(self.texts)

    def __getitem__(self, idx):
        # Tokenize & pad/truncate each text to max_len
        encoding = self.tokenizer(
            self.texts[idx],
            truncation=True,
            padding="max_length",
            max_length=self.max_len
        )
        item = {k: torch.tensor(v) for k, v in encoding.items()}
        item["labels"] = torch.tensor(self.labels[idx], dtype=torch.long)
        return item

# Build dataset objects
train_ds = FakeNewsDataset(
    train_df["combined_text"].tolist(),
    train_labels,
    tokenizer
)
test_ds  = FakeNewsDataset(
    test_df["combined_text"].tolist(),
    test_labels,
    tokenizer
)

# ------------------------------
# 4) Metric computation
# ------------------------------
def compute_metrics(pred):
    labels = pred.label_ids
    preds  = pred.predictions.argmax(-1)
    precision, recall, f1, _ = precision_recall_fscore_support(
        labels, preds, average="macro"
    )
    acc = accuracy_score(labels, preds)
    return {"accuracy": acc, "precision": precision, "recall": recall, "f1": f1}

# ------------------------------
# 5) Load pre-trained RoBERTa for sequence classification
# ------------------------------
model = AutoModelForSequenceClassification.from_pretrained(
    "roberta-large",
    num_labels=2
)

# ------------------------------
# 6) Define training arguments
# ------------------------------
training_args = TrainingArguments(
    output_dir="bert_fakenews_output",    # where to save checkpoints & logs
    num_train_epochs=3,                   # how many times to pass through the data
    per_device_train_batch_size=8,        # train batch size
    per_device_eval_batch_size=16,        # eval batch size

    # checkpoint & eval control
    eval_steps=500,                       # run validation every 500 steps
    save_steps=500,                       # save a checkpoint every 500 steps
    save_total_limit=2,                   # keep only the last 2 checkpoints

    learning_rate=2e-5,                   # starting learning rate
    logging_dir="logs",                   # where to write TensorBoard logs
    logging_steps=50                       # log training metrics every 50 steps
)

# ------------------------------
# 7) Initialize Trainer (no validation dataset)
# ------------------------------
trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=train_ds,
    tokenizer=tokenizer,
    compute_metrics=compute_metrics
)

# ------------------------------
# 8) Train
# ------------------------------
print("=== Starting BERT fine-tuning ===")
trainer.train()

# ------------------------------
# 9) Final test-set evaluation
# ------------------------------
print("\n=== Test Set Metrics ===")
test_out = trainer.predict(test_ds)
print(test_out.metrics)

# Detailed classification report

test_preds = test_out.predictions.argmax(-1)
print("\nClassification Report on Test Set:")
print(classification_report(test_labels, test_preds, target_names=["real", "fake"]))
